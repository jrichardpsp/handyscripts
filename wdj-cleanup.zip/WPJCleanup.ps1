<#
.SYNOPSIS
    Removes Azure AD / Entra ID Workplace Join registrations for a specific tenant
    from all user hives on the local machine.

.DESCRIPTION
    Designed to run as SYSTEM (e.g., via Intune, SCCM, or a startup script) before
    user login. It will:
      1. Load each user's registry hive (NTUSER.DAT) if not already loaded.
      2. Search for Workplace Join entries matching the target Tenant ID.
      3. Remove matching entries from:
           - HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\AAD\Storage
           - HKCU\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WorkplaceJoin\JoinInfo
           - HKCU\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WorkplaceJoin\TenantInfo
      4. Unload any hives that were temporarily loaded.
      5. Log all actions to C:\Windows\Logs\WorkplaceJoinCleanup.log

.PARAMETER TargetTenantId
    The Azure AD / Entra ID Tenant ID (GUID) to remove Workplace Join records for.

.EXAMPLE
    .\WPJCleanup.ps1 -TargetTenantId "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
#>

[CmdletBinding(SupportsShouldProcess)]
param (
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')]
    [string]$TargetTenantId
)

#region --- Configuration ---
$LogFile  = "C:\Windows\Logs\WorkplaceJoinCleanup.log"
$HivesLoaded = [System.Collections.Generic.List[string]]::new()

# Registry paths relative to each user's HKCU
$WPJPaths = @(
    "SOFTWARE\Microsoft\Windows\CurrentVersion\AAD\Storage",
    "SOFTWARE\Microsoft\Windows NT\CurrentVersion\WorkplaceJoin\JoinInfo",
    "SOFTWARE\Microsoft\Windows NT\CurrentVersion\WorkplaceJoin\TenantInfo"
)
#endregion

#region --- Logging ---
function Write-Log {
    param([string]$Message, [ValidateSet('INFO','WARN','ERROR')]$Level = 'INFO')
    $entry = "[{0}] [{1}] {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    Add-Content -Path $LogFile -Value $entry -Encoding UTF8
    switch ($Level) {
        'ERROR' { Write-Host $entry -ForegroundColor Red }
        'WARN'  { Write-Host $entry -ForegroundColor Yellow }
        default { Write-Host $entry }
    }
}
#endregion

#region --- Registry Helpers ---
function Mount-UserHive {
    param([string]$SID, [string]$NTUserDatPath)
    $mountPoint = "HKU\$SID"
    if (Test-Path "Registry::HKEY_USERS\$SID") {
        Write-Log "Hive already loaded for SID $SID  -  skipping mount."
        return $false   # caller should NOT unload this
    }
    Write-Log "Loading hive: $NTUserDatPath -> $mountPoint"
    $result = & reg.exe load "HKU\$SID" "$NTUserDatPath" 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Log "Failed to load hive for SID $SID. reg.exe output: $result" -Level WARN
        return $false
    }
    return $true
}

function Dismount-UserHive {
    param([string]$SID)
    Write-Log "Unloading hive for SID: $SID"
    [gc]::Collect()
    [gc]::WaitForPendingFinalizers()
    $result = & reg.exe unload "HKU\$SID" 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Log "Failed to unload hive for SID $SID. reg.exe output: $result" -Level WARN
    }
}

function Remove-WPJEntriesForTenant {
    param([string]$SID, [string]$TenantId)
    $removed = 0

    foreach ($relPath in $WPJPaths) {
        $fullPath = "Registry::HKEY_USERS\$SID\$relPath"

        if (-not (Test-Path $fullPath)) {
            Write-Log "  Path not found, skipping: $relPath"
            continue
        }

        # Each sub-key under these paths may be keyed by email, UPN, or tenant GUID.
        # We match on TenantId in the key name OR in a 'TenantId' value within the key.
        $subKeys = Get-ChildItem -Path $fullPath -ErrorAction SilentlyContinue

        foreach ($subKey in $subKeys) {
            $matchedByKeyName = $subKey.PSChildName -like "*$TenantId*"

            $tenantValue = (Get-ItemProperty -Path $subKey.PSPath -Name 'TenantId' -ErrorAction SilentlyContinue).TenantId
            $matchedByValue = ($tenantValue -eq $TenantId)

            if ($matchedByKeyName -or $matchedByValue) {
                Write-Log "  Removing key: $($subKey.PSPath)"
                if ($PSCmdlet.ShouldProcess($subKey.PSPath, "Remove registry key")) {
                    try {
                        Remove-Item -Path $subKey.PSPath -Recurse -Force -ErrorAction Stop
                        $removed++
                        Write-Log "  Removed: $($subKey.PSChildName)"
                    } catch {
                        Write-Log "  ERROR removing $($subKey.PSPath): $_" -Level ERROR
                    }
                }
            }
        }

        # Also check if the path key ITSELF contains a TenantId value (some builds store it flat)
        $flatTenant = (Get-ItemProperty -Path $fullPath -Name 'TenantId' -ErrorAction SilentlyContinue).TenantId
        if ($flatTenant -eq $TenantId) {
            Write-Log "  Found flat TenantId value at: $relPath  -  removing parent key"
            if ($PSCmdlet.ShouldProcess($fullPath, "Remove registry key")) {
                Remove-Item -Path $fullPath -Recurse -Force -ErrorAction Stop
                $removed++
            }
        }
    }

    return $removed
}
#endregion

#region --- Transcript ---
$TranscriptPath = "C:\Temp\WDJCleanup.log"
if (-not (Test-Path "C:\Temp")) {
    New-Item -ItemType Directory -Path "C:\Temp" -Force | Out-Null
}
Start-Transcript -Path $TranscriptPath -Append
#endregion

#region --- Main ---
Write-Log "========================================================"
Write-Log "Workplace Join Cleanup started. Target Tenant: $TargetTenantId"
Write-Log "Running as: $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"

# Require SYSTEM / admin
$currentPrincipal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Log "Script must run as Administrator or SYSTEM. Exiting." -Level ERROR
    exit 1
}

# Enumerate local user profiles from the registry (catches all profiles, even if not logged in)
$profileListPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList"
$profiles = Get-ChildItem -Path $profileListPath | Where-Object {
    # Filter to real user SIDs (S-1-5-21-...)  -  skip service/system accounts
    $_.PSChildName -match '^S-1-5-21-'
}

Write-Log "Found $($profiles.Count) user profile(s) to process."

foreach ($profile in $profiles) {
    $sid         = $profile.PSChildName
    $profilePath = (Get-ItemProperty -Path $profile.PSPath -Name 'ProfileImagePath' -ErrorAction SilentlyContinue).ProfileImagePath

    if (-not $profilePath) {
        Write-Log "Could not determine profile path for SID $sid  -  skipping." -Level WARN
        continue
    }

    $ntUserDat = Join-Path $profilePath "NTUSER.DAT"
    Write-Log "Processing SID: $sid  |  Profile: $profilePath"

    if (-not (Test-Path $ntUserDat)) {
        Write-Log "  NTUSER.DAT not found at $ntUserDat  -  skipping." -Level WARN
        continue
    }

    $didMount = Mount-UserHive -SID $sid -NTUserDatPath $ntUserDat

    $count = Remove-WPJEntriesForTenant -SID $sid -TenantId $TargetTenantId
    Write-Log "  Removed $count Workplace Join entry/entries for SID $sid."

    if ($didMount) {
        Dismount-UserHive -SID $sid
    }
}

Write-Log "Workplace Join Cleanup complete."
Write-Log "========================================================"

Stop-Transcript
#endregion