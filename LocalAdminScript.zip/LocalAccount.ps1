# ============================================================
# Create-LocalAdmin.ps1
# Creates (or updates) a local administrative account.
# Must be run as Administrator.
# ============================================================

# --- CONFIGURATION ---
$Username    = "localadmin"
$Password    = "ThisIsMyPassword!"   # <-- Change this to your desired password
$FullName    = "Local Administrator"
$Description = "Local administrative account"
$LogFile     = "C:\Temp\LocalAdmin.log"

# --- LOGGING SETUP ---
if (-not (Test-Path "C:\Temp")) {
    New-Item -ItemType Directory -Path "C:\Temp" | Out-Null
}

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $entry = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    Add-Content -Path $LogFile -Value $entry
    Write-Host $entry
}

Write-Log "Script started on $env:COMPUTERNAME by $env:USERNAME"

# ---------------------------------------------------------------
# Requires elevation
# ---------------------------------------------------------------
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Log "This script must be run as Administrator. Exiting." "ERROR"
    exit 1
}

$SecurePassword = ConvertTo-SecureString $Password -AsPlainText -Force

# ---------------------------------------------------------------
# Create or update the user
# ---------------------------------------------------------------
$existingUser = Get-LocalUser -Name $Username -ErrorAction SilentlyContinue

if ($existingUser) {
    Write-Log "User '$Username' already exists. Updating account..."

    Set-LocalUser -Name $Username `
        -Password $SecurePassword `
        -FullName $FullName `
        -Description $Description `
        -PasswordNeverExpires $true `
        -UserMayChangePassword $false `
        -AccountExpires ([datetime]::MaxValue)   # No expiry

    Enable-LocalUser -Name $Username
    Write-Log "User '$Username' updated successfully."

} else {
    Write-Log "Creating user '$Username'..."

    New-LocalUser -Name $Username `
        -Password $SecurePassword `
        -FullName $FullName `
        -Description $Description `
        -PasswordNeverExpires `
        -AccountNeverExpires

    # UserMayChangePassword is not a New-LocalUser param; set it via Set-LocalUser
    Set-LocalUser -Name $Username -UserMayChangePassword $false

    Enable-LocalUser -Name $Username
    Write-Log "User '$Username' created successfully."
}

# ---------------------------------------------------------------
# Add to local Administrators group (if not already a member)
# ---------------------------------------------------------------
$adminGroup = [System.Security.Principal.SecurityIdentifier]::new(
    [System.Security.Principal.WellKnownSidType]::BuiltinAdministratorsSid, $null
).Translate([System.Security.Principal.NTAccount]).Value.Split('\')[-1]

$isMember = Get-LocalGroupMember -Group $adminGroup -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like "*\$Username" -or $_.Name -eq $Username }

if ($isMember) {
    Write-Log "User '$Username' is already a member of '$adminGroup'. Skipping."
} else {
    Add-LocalGroupMember -Group $adminGroup -Member $Username
    Write-Log "User '$Username' added to '$adminGroup' group."
}

# ---------------------------------------------------------------
# Summary
# ---------------------------------------------------------------
Write-Log "=== Account Summary ==="
$summary = Get-LocalUser -Name $Username | Select-Object Name, Enabled, PasswordExpires, UserMayChangePassword, Description | Format-List | Out-String
Write-Log $summary.Trim()
Write-Log "Script completed."